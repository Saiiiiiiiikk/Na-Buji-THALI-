# My Bujulu — Our tree of memories

A romantic scrolling memory tree, built with a dependency-free Python script.
Includes all 11 photos, six personal memories, touch-to-open notes, a full love
letter, photo enlargement, an editable gift, and a scroll progress indicator.
Photos are displayed together in branch collages; nobody has to click through
an album. It works on phones and computers, with reduced-motion support.

## Run on your Mac

1. Unzip this folder.
2. Open Terminal in the folder containing `app.py`.
3. Run:

```sh
python3 app.py
```

4. Open http://127.0.0.1:8000 in your browser. Ctrl+C stops it.
No pip install or API keys are needed. The Python server is for local previews.

## Make it public with GitHub Pages

1. Create a GitHub repository, for example `my-bujulu`.
2. Upload the contents of this folder, keeping `docs/` and `docs/photos/`
   intact. Upload the extracted files, not the ZIP. `app.py`, `gift.json`,
   `template.html`, and `docs/` should be at the repository root.
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/docs`, then Save.
6. GitHub will show your published URL in Pages when the deployment is ready.
   It will usually look like https://YOUR-USERNAME.github.io/my-bujulu/.
   Share that URL with Bujulu. Your computer does not need to stay on.

GitHub Pages serves the prebuilt `docs/` website; it does not execute Python.
The included Python script builds that website, and can also preview it locally.

Official guide:
https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

The GitHub Pages website and its included photos and letter are public.
A public repository also exposes the source files. Keep this in mind when
choosing which personal photos and words to publish.

## Change your words

Use the website's Personalise button and Create gift link to send a version
with your new text. This draft is saved only in your browser, and each gift
link contains its own messages. These are shareable links, not secret links.

To change the default text for everyone:

1. Edit `gift.json`, keeping it valid JSON.
2. Run `python3 app.py --build`.
3. Upload/commit the changed `gift.json` and `docs/index.html` to GitHub.

To replace a photo, replace its `docs/photos/memory-N.jpg` file. Keep the
filenames `memory-1.jpg` through `memory-11.jpg`, or update `template.html`
to use your new filenames. Run the build command after template changes.

## Files

- app.py — Python builder and local server
- gift.json — your letter and memory text
- template.html — the interactive memory-tree design
- docs/index.html — ready-to-publish website
- docs/photos/ — all 11 included photos
- docs/.nojekyll — use the files directly on GitHub Pages

No ChatGPT branding appears on the page. GitHub Pages uses a github.io URL;
use your own domain if you want a completely personal web address.
