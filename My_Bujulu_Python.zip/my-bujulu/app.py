#!/usr/bin/env python3
"""My Bujulu: a dependency-free Python memory-tree app and static-site builder."""
import argparse
import functools
import http.server
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def build():
    gift = json.loads((ROOT / 'gift.json').read_text(encoding='utf-8'))
    # Escape script boundaries so personal text cannot become executable HTML.
    payload = json.dumps(gift, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    template = (ROOT / 'template.html').read_text(encoding='utf-8')
    docs = ROOT / 'docs'
    docs.mkdir(exist_ok=True)
    missing = [f'memory-{i}.jpg' for i in range(1, 12) if not (docs / 'photos' / f'memory-{i}.jpg').is_file()]
    if missing:
        raise FileNotFoundError('Keep the included docs/photos folder: ' + ', '.join(missing))
    (docs / 'index.html').write_text(template.replace('__GIFT_DATA__', payload), encoding='utf-8')
    (docs / '.nojekyll').touch()
    return docs

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true', help='Regenerate docs for GitHub Pages and exit')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--host', default='127.0.0.1')
    args = parser.parse_args()
    docs = build()
    if args.build:
        print('Built docs/index.html. Commit docs/ to GitHub to publish your changes.')
        return
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(docs))
    with http.server.ThreadingHTTPServer((args.host, args.port), handler) as server:
        print(f'My Bujulu is ready: http://{args.host}:{args.port}')
        print('Press Ctrl+C to stop.')
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('\nWith love, goodbye.')

if __name__ == '__main__':
    main()
